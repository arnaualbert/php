<?php

/**
 * Model for store application.
 *
 * @author ProvenSoft
 */
class Model {
    
    public function __construct() {
        
    }

    /** methods related to user **/
    
    /**
     * searches all users in data source.
     * @return array with all users found or null in case of error.
     */
    public function searchAllUsers(): ?array {
        $data = null;
        //TODO
        return $data;
    }    
    
    /**
     * adds a new user to data source preventing username duplicated and null
     * objects
     * @param User $user the user to add
     * @return int number of users added
     */
    public function addUser(User $user) : int {
        $result = 0;
        //TODO
        return $result;
    }
    
    /** methods related to product **/
    
   /**
    * Search a User by username and password
    * @param string $username
    * @param string $password
    * @return User found or null if not exists
    */
    public function searchUserByUsernameAndPassword(
            string $username, 
            string $password
            ): ?User {
        $found = null;
        //TODO
        return $found;
    }
    
    /**
     * searches a user with the given username
     * @param string $username the username to search
     * @return the user searched or null if not found
     */
    public function searchUserByUsername(string $username): ?User {
       //TODO
    }
}