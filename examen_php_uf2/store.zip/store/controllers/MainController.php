<?php
require_once 'lib/ViewLoader.php';
require_once 'model/Model.php';
/**
 * Main controller for store application.
 *
 * @author ProvenSoft
 */
class MainController {
    /**
     * @var Model $model. The model to provide data services. 
     */
    private Model $model;
    /**
     * @var ViewLoader $view. The loader to forward views. 
     */
    private ViewLoader $view;
    /**
     * @var string $action. The action requested by client. 
     */
    private string $action;
    
    public function __construct() {
        //instantiate the view loader.
        $this->view = new ViewLoader();
        //instantiate the model.
        $this->model = new Model();
    }
    
    /**
     * processes requests made by client.
     */
    public function processRequest() {
        $requestMethod = filter_input(INPUT_SERVER, 'REQUEST_METHOD');          
        switch ($requestMethod) {
            case 'GET':
            case 'get':
                $this->processGet();
                break;
            case 'POST':
            case 'post':
                $this->processPost();
                break;
            default:
                $this->processError();
                break;
        }
    } 
    
    /**
     * processes get request made by client.
     */
    private function processGet() {
        $this->action = "";
        if (filter_has_var(INPUT_GET, 'action')) {
            $this->action = filter_input(INPUT_GET, 'action'); 
        }
        switch ($this->action) {
            case 'home':  //home page.
                $this->doHomePage();
                break;
            //TODO
            default:  //processing default action.
                $this->doHomePage();
                break;
        }
    }
    
    /**
     * processes post request made by client.
     */
    private function processPost() {
       $this->action = "";
       if (filter_has_var(INPUT_POST, 'action')) {
            $this->action = filter_input(INPUT_POST, 'action'); 
        }
        switch ($this->action) {
            //TODO
            default:  //processing default action.
                $this->doHomePage();
                break;
        }        
    }    
 
    /**
     * processes error.
     */
    private function processError() {
        trigger_error("Bad method", E_USER_NOTICE);
    }      

}