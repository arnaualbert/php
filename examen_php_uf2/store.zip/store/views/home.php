<h2>Store application</h2>
<p>Welcome to Store manager</p>